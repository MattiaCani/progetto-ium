package com.example.progetto;

import java.io.Serializable;


public class Person implements Serializable {
    private String username, password, email, vehicle;



    public Person(){
        this.setUsername("");
        this.setPassword("");
        this.setEmail("");
        this.setVehicle("");
    }

    public Person(String username, String password, String email, String vehicle){
        this.username = username;
        this.password = password;
        this.email = email;
        this.vehicle = vehicle;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getVehicle() {
        return vehicle;
    }

    public void setVehicle(String vehicle) {
        this.vehicle = vehicle;
    }
}
