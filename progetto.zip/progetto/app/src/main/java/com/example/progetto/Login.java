package com.example.progetto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.*;

public class Login extends AppCompatActivity {

    EditText editUsername, editPassword;
    TextView regLink;
    Button loginButton;
    public static final String PERSON_EXTRA =
            "com.example.progetto.Person";

    //credenziali dell'utente di root che non devono essere modificate
    Person root = new Person("root","pswroot","milano", "SUV");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        loginButton = findViewById(R.id.loginButton);
        regLink = findViewById(R.id.reg_link);

        //click listener per il tasto di login
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkRoot()){
                    Intent showResult = new Intent(Login.this,
                            Login.class);   //da cambiare, deve portare a home
                    showResult.putExtra(PERSON_EXTRA, root);
                    startActivity(showResult);
                }

            }
        });

        //click listener per il link di registrazione
        regLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registrationPage = new Intent(Login.this,
                        SignIn.class); //da cambiare, deve portare a registrazione
                startActivity(registrationPage);
            }
        });
    }

    boolean checkRoot() {   //per controllare eventuali errori nel root
        int correct = 0;
        if (editUsername.getText().toString().equals(root.getUsername()))
            correct++;
        if (editPassword.getText().toString().equals(root.getPassword()))
            correct++;
        if(correct == 2)
            return true;
        else
            return false;
    }


}

